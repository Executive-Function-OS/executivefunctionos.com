# Master Visual Identity System: Structural Clarity & Dynamic Resonance

Single source of truth for Annika Eriksson's web presence, digital tools, and application interfaces. Derived directly from the Canva AI Visual Identity System. All digital tools and web properties branch from this foundation, integrating these core tokens and principles regardless of project-specific features.

## 1. Core Essence & Philosophy

- **Core Essence:** Structural Clarity & Dynamic Resonance
- **Guiding Axiom:** Utility over ornament. Signals should be clear, scannable, and actionable.
- **Value Proposition:** Translating complex systems into transparent, functional frameworks that maximize agency and practical outcomes.
- **Three Pillars:** Analytical Rigor + Creative Synthesis + Resilience & Pragmatism
- **Structural Model:**
  - Node = Structure
  - Connection = Relationship
  - Flow = Resonance

### Taglines
- **Primary:** Structured Thought. Functional Action.
- **Alternate 01:** Clarity in Complex Systems.
- **Alternate 02:** Architecture Through Analysis.

## 2. Color Architecture & Accessibility

Every color pairing has been validated for accessibility and readability across high-density layouts.

- **Primary Base / Deep Slate:** `#0F172A`
  - Stable, high-contrast grounding for typography, layout borders, and dark-theme canvas.
  - Contrast ratio against Chalk White: 21.0:1 (AAA Pass).
- **Accent / Action / Signal Teal:** `#0D9488`
  - Directs focus toward active components, data points, interactive hover/active states, and primary CTAs.
  - Contrast ratio against Deep Slate: 4.7:1 (AAA Large / AA Normal Pass).
- **Warm Accent / Resonant Amber:** `#D97706`
  - Introduces warmth and energy, balancing pure technical analysis. Marks caution states, urgent notifications, and focal transition nodes.
  - Contrast ratio against Deep Slate: 4.5:1 (AAA Large / AA Normal Pass).
- **Neutral Canvas / Chalk White:** `#F8FAFC`
  - Maximizes legibility and minimizes cognitive load across text-heavy layouts and reports.
  - Contrast ratio: 4.6:1 (AAA Pass).

### State Indicators
- **Active / Positive State:** `#0D9488` (Signal Teal)
- **Caution / Attention State:** `#D97706` (Resonant Amber)
- **Disabled State:** `#94A3B8` on `#F1F5F9` background

## 3. Typography Hierarchy

Consistent hierarchy. Clear intent. Preserves high reading comprehension during intensive analysis.

- **Display / Headlines:** `Space Grotesk` or `Inter`
  - Usage: H1, H2, hero banners, section titles.
  - Characteristics: Clean, geometric, modern proportions for objectivity, structure, and precision.
- **Technical / Metadata:** `JetBrains Mono` or `Fira Code`
  - Usage: Pleading numbers, citation tags, table figures, code blocks, delta trends, report IDs, status badges.
  - Characteristics: Monospace clarity, tabular figures, high distinction between similar glyphs (0 vs O, 1 vs l).
- **Editorial / Prose:** `Charter` or `Inter Regular`
  - Usage: Long-form analysis, legal arguments, executive summaries, narrative sections.
  - Characteristics: High legibility at small and long-form scales for sustained reading.

## 4. Mark System & Scalability

Master vector assets located in [Visual_Identity_System](file:///home/annika/Documents/Visual_Identity_System):

- **Primary Mark: The Harmonic Lattice (Recommended)**
  - File: [harmonic-lattice-isometric.svg](file:///home/annika/Documents/Visual_Identity_System/harmonic-lattice-isometric.svg)
  - Concept: Interconnected nodes transition into continuous wave contours, mapping complex systems while maintaining human-scale resonance.
  - Features: Deep Slate `#0F172A` base lattice, Signal Teal `#0D9488` transition nodes and wave paths, and a single Resonant Amber `#D97706` focal node at the transition nexus.
- **Schematic Mark: The Harmonic Lattice Grid**
  - File: [harmonic-lattice-grid.svg](file:///home/annika/Documents/Visual_Identity_System/harmonic-lattice-grid.svg)
  - Concept: 12x12 Cartesian matrix (Columns A-D, Rows 01-04) demonstrating structural lattice progression into dynamic sine waves.
- **Secondary Mark: The Threshold Node**
  - File: [threshold-node.svg](file:///home/annika/Documents/Visual_Identity_System/threshold-node.svg)
  - Concept: Open circular form intersected by a directional vector—representing phase transitions, critical clarity, and forward motion.
- **Favicon & Small Icon:**
  - Files: [favicon.svg](file:///home/annika/Documents/Visual_Identity_System/favicon.svg), [favicon-32.png](file:///home/annika/Documents/Visual_Identity_System/favicon-32.png), [favicon-16.png](file:///home/annika/Documents/Visual_Identity_System/favicon-16.png)
  - 16x16 / 32x32 node matrix test preserving legibility in tab bars and bookmark lists.

## 5. Application Framework & UI Components

- **Layout Grid:** 12-column / 12-row underlying grid with 1.5X margins. Faint hairline grid lines with technical crosshairs (`+`) at major quadrant axes.
- **Modular Cards:** Crisp 1px borders (`#E2E8F0` on light, `#334155` on dark), subtle technical elevation, visible structure without unnecessary drop-shadow clutter.
- **Monochromatic Tabular Data:** Monospace records, concise marginal annotations, right-aligned numbers with color-coded delta indicators (`+` in Teal, `-` or caution in Amber).
- **Interactive State Buttons:**
  - Default: Transparent/White background, 1px `#0F172A` border, dark text.
  - Hover: Soft `#F0FDFA` teal background, `#0D9488` border, `#0D9488` text.
  - Active: Solid `#0D9488` fill, `#F8FAFC` white text.
  - Disabled: `#F1F5F9` gray fill, `#CBD5E1` border, `#94A3B8` text.
  - Alert: Transparent background, 1px `#D97706` border, `#D97706` text.

## 6. Integration Guide for Web Projects

Every project across Annika's web presence integrates this system as its core:

### Direct CSS Import
Link [tokens.css](file:///home/annika/Documents/Visual_Identity_System/tokens.css) in any HTML document or application entry point:
```html
<link rel="stylesheet" href="/path/to/Visual_Identity_System/tokens.css">
```

### Tailwind CSS Projects
Import the preset into `tailwind.config.js`:
```javascript
module.exports = {
  presets: [require('/home/annika/Documents/Visual_Identity_System/tailwind.preset.js')],
  // project-specific overrides
};
```

### Existing Projects Integration Checklist
- **JustiTeX:** Transition accent purple (`#8b5cf6`) to Signal Teal (`#0D9488`), dark backgrounds to Deep Slate (`#0F172A`), and caution highlights to Resonant Amber (`#D97706`).
- **hyperRAG:** Align card borders and active tab indicators with Deep Slate (`#0F172A`) and Signal Teal (`#0D9488`).
- **Personal Web Presence & Showcase:** Use [index.html](file:///home/annika/Documents/Visual_Identity_System/index.html) as the baseline template for modular reporting, case timelines, and product showcases.

## 7. Master File Directory

- Master PDF: [Complete visual identity system.pdf](file:///home/annika/Documents/Visual_Identity_System/Complete%20visual%20identity%20system.pdf)
- Interactive Showcase: [index.html](file:///home/annika/Documents/Visual_Identity_System/index.html)
- CSS Tokens: [tokens.css](file:///home/annika/Documents/Visual_Identity_System/tokens.css)
- JSON Tokens: [tokens.json](file:///home/annika/Documents/Visual_Identity_System/tokens.json)
- Tailwind Preset: [tailwind.preset.js](file:///home/annika/Documents/Visual_Identity_System/tailwind.preset.js)
- Page Previews: [page-1.png](file:///home/annika/Documents/Visual_Identity_System/page-1.png) to [page-6.png](file:///home/annika/Documents/Visual_Identity_System/page-6.png)
