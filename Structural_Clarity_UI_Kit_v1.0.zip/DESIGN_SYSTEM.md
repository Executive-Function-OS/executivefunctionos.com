# Master Visual Identity System: Structural Clarity & Dynamic Resonance

Single source of truth for Annika Eriksson's web presence, digital tools, and application interfaces. Derived directly from the Canva AI Visual Identity System. All digital tools and web properties branch from this foundation, integrating these core tokens and principles regardless of project-specific features.

## 1. Core Essence & Philosophy

- **Core Essence:** Structural Clarity & Dynamic Resonance
- **Guiding Axiom:** Utility over ornament. Signals should be clear, scannable, and actionable.
- **Value Proposition:** Translating complex systems into transparent, functional frameworks that maximize agency and practical outcomes.
- **Three Pillars:** Analytical Rigor + Creative Synthesis + Resilience & Pragmatism
- **Structural Model:**
  - Node = Structure
  - Connection = Relationship
  - Flow = Resonance

### Taglines
- **Primary:** Structured Thought. Functional Action.
- **Alternate 01:** Clarity in Complex Systems.
- **Alternate 02:** Architecture Through Analysis.

## 2. Color Architecture & Accessibility

Every color pairing has been validated for accessibility and readability across high-density layouts.

- **Primary Base / Deep Slate:** `#0F172A`
  - Stable, high-contrast grounding for typography, layout borders, and dark-theme canvas.
  - Contrast ratio against Chalk White: 21.0:1 (AAA Pass).
- **Accent / Action / Signal Teal:** `#0D9488`
  - Directs focus toward active components, data points, interactive hover/active states, and primary CTAs.
  - Contrast ratio against Deep Slate: 4.7:1 (AAA Large / AA Normal Pass).
- **Warm Accent / Resonant Amber:** `#D97706`
  - Introduces warmth and energy, balancing pure technical analysis. Marks caution states, urgent notifications, and focal transition nodes.
  - Contrast ratio against Deep Slate: 4.5:1 (AAA Large / AA Normal Pass).
- **Neutral Canvas / Chalk White:** `#F8FAFC`
  - Maximizes legibility and minimizes cognitive load across text-heavy layouts and reports.
  - Contrast ratio: 4.6:1 (AAA Pass).

### State Indicators
- **Active / Positive State:** `#0D9488` (Signal Teal)
- **Caution / Attention State:** `#D97706` (Resonant Amber)
- **Disabled State:** `#94A3B8` on `#F1F5F9` background

## 3. Typography Hierarchy

Consistent hierarchy. Clear intent. Preserves high reading comprehension during intensive analysis.

- **Display / Headlines:** `Space Grotesk` or `Inter`
  - Usage: H1, H2, hero banners, section titles.
  - Characteristics: Clean, geometric, modern proportions for objectivity, structure, and precision.
- **Technical / Metadata:** `JetBrains Mono` or `Fira Code`
  - Usage: Pleading numbers, citation tags, table figures, code blocks, delta trends, report IDs, status badges.
  - Characteristics: Monospace clarity, tabular figures, high distinction between similar glyphs (0 vs O, 1 vs l).
- **Editorial / Prose:** `Charter` or `Inter Regular`
  - Usage: Long-form analysis, legal arguments, executive summaries, narrative sections.
  - Characteristics: High legibility at small and long-form scales for sustained reading.

## 4. Mark System & Scalability

Master vector assets located in [Visual_Identity_System](file:///home/annika/Documents/Visual_Identity_System):

- **Primary Mark: The Harmonic Lattice (Recommended)**
  - File: [harmonic-lattice-isometric.svg](file:///home/annika/Documents/Visual_Identity_System/harmonic-lattice-isometric.svg)
  - Concept: Interconnected nodes transition into continuous wave contours, mapping complex systems while maintaining human-scale resonance.
  - Features: Deep Slate `#0F172A` base lattice, Signal Teal `#0D9488` transition nodes and wave paths, and a single Resonant Amber `#D97706` focal node at the transition nexus.
- **Schematic Mark: The Harmonic Lattice Grid**
  - File: [harmonic-lattice-grid.svg](file:///home/annika/Documents/Visual_Identity_System/harmonic-lattice-grid.svg)
  - Concept: 12x12 Cartesian matrix (Columns A-D, Rows 01-04) demonstrating structural lattice progression into dynamic sine waves.
- **Mathematical Generator: Isometric Harmonic Lattice (Pure Vector Math)**
  - File: [harmonic-lattice-mathematical.svg](file:///home/annika/Documents/Visual_Identity_System/harmonic-lattice-mathematical.svg)
  - Concept: Pure mathematical SVG generator (`rhombus(cx, cy, w, h)`, origin 188, 18, 12x11 Cartesian coordinate matrix). Features coordinate-mapped Signal Teal nodes, real-time pulsing Resonant Amber focal nexus (`.pulse-amber`), and flowing transition sine wave.
- **Secondary Mark: The Threshold Node**
  - File: [threshold-node.svg](file:///home/annika/Documents/Visual_Identity_System/threshold-node.svg)
  - Concept: Open circular form intersected by a directional vector—representing phase transitions, critical clarity, and forward motion.
- **Favicon & Small Icon:**
  - Files: [favicon.svg](file:///home/annika/Documents/Visual_Identity_System/favicon.svg), [favicon-32.png](file:///home/annika/Documents/Visual_Identity_System/favicon-32.png), [favicon-16.png](file:///home/annika/Documents/Visual_Identity_System/favicon-16.png)
  - 16x16 / 32x32 node matrix test preserving legibility in tab bars and bookmark lists.

## 5. Application Framework & UI Components

- **Layout Grid:** 12-column / 12-row underlying grid with 1.5X margins. Faint hairline grid lines with technical crosshairs (`+`) at major quadrant axes.
- **Modular Cards:** Crisp 1px borders (`#E2E8F0` on light, `#334155` on dark), subtle technical elevation, visible structure without unnecessary drop-shadow clutter.
- **Monochromatic Tabular Data:** Monospace records, concise marginal annotations, right-aligned numbers with color-coded delta indicators (`+` in Teal, `-` or caution in Amber).
- **Interactive State Buttons:**
  - Default: Transparent/White background, 1px `#0F172A` border, dark text.
  - Hover: Soft `#F0FDFA` teal background, `#0D9488` border, `#0D9488` text.
  - Active: Solid `#0D9488` fill, `#F8FAFC` white text.
  - Disabled: `#F1F5F9` gray fill, `#CBD5E1` border, `#94A3B8` text.
  - Alert: Transparent background, 1px `#D97706` border, `#D97706` text.

### Kinetic Clarity Button System (24 Animated CSS Styles)
Imported automatically via [tokens.css](file:///home/annika/Documents/Visual_Identity_System/tokens.css) or standalone via [kinetic_clarity_buttons.css](file:///home/annika/Documents/Visual_Identity_System/kinetic_clarity_buttons.css). Live test playground at [buttons.html](file:///home/annika/ExecutiveFunctionOS_Web/buttons.html).

- **Base Architecture:** `.sc-btn` (with backward-compatible drop-in aliases `.kb-btn`)
- **Scale & Geometry:** `.sc-btn--sm`, `.sc-btn--lg`, `.sc-btn--pill`, `.sc-btn--sharp`, `.sc-btn--block`
- **Variants (24 Total):**
  1. *Gradients:* `.sc-gradient-teal` (Signal Ocean), `.sc-gradient-amber` (Sunrise), `.sc-gradient-aurora` (Lattice Wave), `.sc-gradient-twilight` (Cosmic Depth)
  2. *Glassmorphism:* `.sc-glass-frost` (Chalk Blur), `.sc-glass-dark` (Deep Obsidian), `.sc-glass-prism` (Chromatic Lattice Mask)
  3. *Harmonic Glow:* `.sc-neon-teal` (Phosphor Signal), `.sc-neon-amber` (Urgent Amber), `.sc-neon-chalk` (White Specular)
  4. *Neumorphic:* `.sc-neumorphic-soft` (Light Extrusion), `.sc-neumorphic-dark` (Slate Monolith), `.sc-neumorphic-concave` (Curved Halo)
  5. *Kinetic Motion:* `.sc-kinetic-shimmer` (Laser Photon Beam), `.sc-kinetic-pulse` (Harmonic Radar Ring), `.sc-kinetic-border` (360° Conic Orbit), `.sc-kinetic-float` (Sinusoidal Elevation), `.sc-kinetic-glitch` (Diagnostic Slicing)
  6. *Ghost & HUD:* `.sc-outline-minimal` (Hairline Inversion), `.sc-outline-gradient` (Multi-Tone Rim), `.sc-outline-bracket` (Expanding HUD Brackets)
  7. *3D Tactile Keys:* `.sc-3d-amber` (Mechanical Amber Switch), `.sc-3d-slate` (Mechanical Slate Keycap), `.sc-3d-teal` (Signal Cyber Press)
- **Accessibility:** Fully supports `@media (prefers-reduced-motion: reduce)` by disabling animations, with WCAG AAA `:focus-visible` ring contrast.

## 6. Integration Guide for Web Projects

Every project across Annika's web presence integrates this system as its core:

### Direct CSS Import
Link [tokens.css](file:///home/annika/Documents/Visual_Identity_System/tokens.css) in any HTML document or application entry point:
```html
<link rel="stylesheet" href="/path/to/Visual_Identity_System/tokens.css">
```

### Tailwind CSS Projects
Import the preset into `tailwind.config.js`:
```javascript
module.exports = {
  presets: [require('/home/annika/Documents/Visual_Identity_System/tailwind.preset.js')],
  // project-specific overrides
};
```

### Existing Projects Integration Checklist
- **JustiTeX:** Transition accent purple (`#8b5cf6`) to Signal Teal (`#0D9488`), dark backgrounds to Deep Slate (`#0F172A`), and caution highlights to Resonant Amber (`#D97706`).
- **hyperRAG:** Align card borders and active tab indicators with Deep Slate (`#0F172A`) and Signal Teal (`#0D9488`).
- **Personal Web Presence & Showcase:** Use [index.html](file:///home/annika/Documents/Visual_Identity_System/index.html) as the baseline template for modular reporting, case timelines, and product showcases.

## 7. Master File Directory

- Master PDF: [Complete visual identity system.pdf](file:///home/annika/Documents/Visual_Identity_System/Complete%20visual%20identity%20system.pdf)
- Interactive Showcase: [index.html](file:///home/annika/Documents/Visual_Identity_System/index.html)
- Interactive Component Studio & Telemetry Lab: [lab.html](file:///home/annika/ExecutiveFunctionOS_Web/lab.html)
- Interactive Buttons Playground: [buttons.html](file:///home/annika/Documents/Visual_Identity_System/buttons.html)
- Mathematical SVG Lattice: [harmonic-lattice-mathematical.svg](file:///home/annika/Documents/Visual_Identity_System/harmonic-lattice-mathematical.svg)
- CSS Tokens: [tokens.css](file:///home/annika/Documents/Visual_Identity_System/tokens.css)
- Kinetic Buttons CSS: [kinetic_clarity_buttons.css](file:///home/annika/Documents/Visual_Identity_System/kinetic_clarity_buttons.css)
- JSON Tokens: [tokens.json](file:///home/annika/Documents/Visual_Identity_System/tokens.json)
- Tailwind Preset: [tailwind.preset.js](file:///home/annika/Documents/Visual_Identity_System/tailwind.preset.js)
- Page Previews: [page-1.png](file:///home/annika/Documents/Visual_Identity_System/page-1.png) to [page-6.png](file:///home/annika/Documents/Visual_Identity_System/page-6.png)
- Paladin Knight Mark: [paladin-knight-mark.svg](file:///home/annika/Documents/Visual_Identity_System/paladin-knight-mark.svg)
- Paladin Favicon: [favicon-paladin.svg](file:///home/annika/Documents/Visual_Identity_System/favicon-paladin.svg)

## 8. Juridical Sub-Theme: JudgeSmoke (PALADIN A2J Profile)

The specialized courtroom and access-to-justice (A2J) profile of the master visual identity system. Built for self-represented litigants, legal aid clinics, and pro bono legal technology. Reinterprets the digital tokens of Structural Clarity & Dynamic Resonance onto the tactile physical medium of legal pleading paper.

- **Philosophy:** *Have Brief — Will Gavel.* Leveling the procedural playing field against institutional syndicates through strict evidentiary adherence to unbroken common-law rules.
- **Palette Translation:**
  - `Neutral Canvas (#F8FAFC)` &rarr; `Pleading Cream (#F3EADC)`: 24lb heavy linen legal paper stock.
  - `Primary Base (#0F172A)` &rarr; `Deep Pleading Ink (#1C1710)`: High-contrast dense charcoal pleading text.
  - `Signal Teal (#0D9488)` &rarr; `Courthouse Stamp Teal (#1F5F58)`: Deep clerk archival stamp ink and docket seals.
  - `Resonant Amber (#D97706)` &rarr; `Calling Card Terracotta (#C45C3E)`: Earthy iron-oxide calling card and urgent procedural flags.
- **Grid Translation:**
  - Bridges the 12-column Cartesian grid with Oregon UTCR 28-line numbered pleading paper, double left margin vertical rules, and formal two-column caption geometry.
- **Heraldic Mark:**
  - [paladin-knight-mark.svg](file:///home/annika/Documents/Visual_Identity_System/paladin-knight-mark.svg): High-contrast courthouse teal tile with cream knight silhouette and terracotta accent.
  - [favicon-paladin.svg](file:///home/annika/Documents/Visual_Identity_System/favicon-paladin.svg): 16x16 pixel-crisp SVG knight mark.
- **Live Portal:** [paladin.html](file:///home/annika/ExecutiveFunctionOS_Web/paladin.html) (Live: `https://executive-function-os.github.io/executivefunctionos.com/paladin.html`)
