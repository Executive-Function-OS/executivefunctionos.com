# Structural Clarity UI Kit — Commercial License & Quickstart Guide

Thank you for purchasing the **Structural Clarity UI Kit** — the production design system for analytical systems architecture, structured problem-solving, and creative resonance.

## What's Included in This Package

1. **tokens.css**: Production CSS design tokens defining colors (Deep Slate, Signal Teal, Resonant Amber, Chalk White), typography variables, modular card classes, monochromatic tables, and interactive state indicators.
2. **tokens.json**: Standard design token format compatible with Style Dictionary, Figma Tokens, and modern build tooling.
3. **tailwind.preset.js**: Plug-and-play Tailwind CSS preset ready to include in your `tailwind.config.js`.
4. **Vector Marks**: High-resolution vector SVGs of *The Harmonic Lattice* (Isometric & Schematic Grid), *The Threshold Node*, and Favicon matrices.
5. **templates/dashboard_template.html**: Complete responsive dashboard template featuring telemetry metrics, modular data cards, and state controls.
6. **DESIGN_SYSTEM.md**: Complete architectural brand guidelines and accessibility contrast ratios.

## Commercial License Grant

This license grants you (the individual or organization licensee) a non-exclusive, perpetual, worldwide right to:
- Use these design assets, templates, code, and tokens in unlimited commercial, client, or personal applications.
- Modify, rebrand, and adapt the components to suit your projects.
- Ship the code inside closed-source or open-source software, SaaS platforms, internal corporate dashboards, or client deliverables.

## Restrictions
- You may not redistribute, resell, or sublicense this kit as a standalone design system, template pack, or digital asset library.

## Quickstart

### Option 1: Vanilla HTML / CSS
Link the stylesheet in your `<head>`:
```html
<link rel="stylesheet" href="tokens.css">
```

### Option 2: Tailwind CSS
Add the preset to `tailwind.config.js`:
```javascript
module.exports = {
  presets: [require('./tailwind.preset.js')],
  // your custom configuration
};
```

Built with Structural Clarity & Dynamic Resonance.
Designed by Annika Eriksson.
